package com.freeyou

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.freeyou.data.AdultBlockEngine
import com.freeyou.data.BlockRepo

class BlockerAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "FreeYouBlocker"
        private const val MAX_TREE_DEPTH = 14
        private const val MAX_SCREEN_TEXT_CHARS = 16_000

        private val BROWSER_URL_IDS = listOf(
            "com.android.chrome:id/url_bar",
            "com.android.chrome:id/search_box_text",
            "com.android.chrome:id/line_1",
            "com.android.chrome:id/toolbar",
            "org.mozilla.firefox:id/url_bar_title",
            "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
            "org.mozilla.firefox:id/url_bar",
            "com.brave.browser:id/url_bar",
            "com.brave.browser:id/search_box_text",
            "com.opera.browser:id/url_field",
            "com.opera.mini.native:id/url_field",
            "com.opera.gx:id/url_field",
            "com.sec.android.app.sbrowser:id/location_bar_edit_text",
            "com.sec.android.app.sbrowser:id/url_bar",
            "com.microsoft.emmx:id/url_bar",
            "com.microsoft.emmx:id/search_box",
            "com.duckduckgo.mobile.android:id/omnibarTextInput",
            "com.google.android.googlequicksearchbox:id/googleapp_search_box",
            "com.kiwibrowser.browser:id/url_bar",
            "com.vivaldi.browser:id/url_bar"
        )

        private val DEEP_SCAN_PACKAGES = setOf(
            "com.android.chrome",
            "org.mozilla.firefox",
            "com.brave.browser",
            "com.opera.browser",
            "com.opera.mini.native",
            "com.opera.gx",
            "com.sec.android.app.sbrowser",
            "com.microsoft.emmx",
            "com.duckduckgo.mobile.android",
            "com.kiwibrowser.browser",
            "com.vivaldi.browser",
            "com.twitter.android",
            "com.x.android",
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.instagram.android",
            "com.reddit.frontpage",
            "org.telegram.messenger",
            "org.telegram.plus"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "FreeYou Accessibility Blocker connected.")
        BlockRepo.init(this)
        MentorOverlay.init(this)
        AdultShieldUpdater.maybeRefresh(this)
    }

    override fun onAccessibilityEvent(ev: AccessibilityEvent?) {
        if (ev == null) return

        val pkg = ev.packageName?.toString() ?: return

        // Hard self-protection: FreeYou UI is never inspected, scored or treated as a blocked app.
        // Context.packageName is the runtime applicationId (com.aistudio.freeyou.app in this build).
        if (isOwnPackage(pkg)) return

        BlockRepo.init(this)
        AdultShieldUpdater.maybeRefresh(this)

        val appBlock = BlockRepo.isAppBlocked(pkg, ev.className?.toString())
        if (appBlock != null) {
            trigger(appBlock)
            return
        }

        val root = rootInActiveWindow ?: return
        if (isOwnPackage(root.packageName?.toString())) {
            @Suppress("DEPRECATION")
            root.recycle()
            return
        }

        try {
            if (pkg == "com.android.settings" && BlockRepo.state.value.strict) {
                if (checkSettingsAntiBypass(root)) {
                    trigger("הגדרות נגישות (מצב קשוח פעיל)")
                    return
                }
            }

            // Full sexual-content scoring is intentionally limited to browsers/social apps or an
            // unknown app that clearly exposes a URL bar. This prevents false positives in FreeYou,
            // banking, settings, health apps, chats, etc.
            val deepScan = pkg in DEEP_SCAN_PACKAGES || hasUrlLikeNode(root, 0)

            if (deepScan) {
                val screenText = StringBuilder()
                collectVisibleText(root, 0, screenText)
                val screenHit = AdultBlockEngine.checkScreenText(screenText)
                if (screenHit != null) {
                    trigger(screenHit)
                    return
                }
            }

            val detectedBlock = inspectNodeHierarchy(root, 0, deepScan)
            if (detectedBlock != null) trigger(detectedBlock)
        } catch (t: Throwable) {
            Log.e(TAG, "Error inspecting accessibility window: ${t.message}", t)
        } finally {
            @Suppress("DEPRECATION")
            root.recycle()
        }
    }

    private fun isOwnPackage(pkg: String?): Boolean {
        return !pkg.isNullOrBlank() && pkg == applicationContext.packageName
    }

    private fun hasUrlLikeNode(node: AccessibilityNodeInfo, depth: Int): Boolean {
        if (depth > 8) return false
        val viewId = node.viewIdResourceName?.lowercase().orEmpty()
        if (isUrlViewId(viewId)) return true

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (hasUrlLikeNode(child, depth + 1)) return true
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }
        return false
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo, depth: Int, out: StringBuilder) {
        if (depth > MAX_TREE_DEPTH || out.length >= MAX_SCREEN_TEXT_CHARS) return

        val text = node.text?.toString()?.trim()
        if (!text.isNullOrBlank()) out.append(' ').append(text.take(800))

        val desc = node.contentDescription?.toString()?.trim()
        if (!desc.isNullOrBlank()) out.append(' ').append(desc.take(800))

        for (i in 0 until node.childCount) {
            if (out.length >= MAX_SCREEN_TEXT_CHARS) break
            val child = node.getChild(i) ?: continue
            try {
                collectVisibleText(child, depth + 1, out)
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }
    }

    private fun inspectNodeHierarchy(
        node: AccessibilityNodeInfo,
        depth: Int,
        scanContent: Boolean
    ): String? {
        if (depth > MAX_TREE_DEPTH) return null
        if (isOwnPackage(node.packageName?.toString())) return null

        val viewId = node.viewIdResourceName?.lowercase().orEmpty()
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()

        if (isUrlViewId(viewId) && !text.isNullOrBlank()) {
            BlockRepo.isUrlBlocked(text)?.let { return it }
            if (scanContent) BlockRepo.checkContentTrigger(text)?.let { return it }
        }

        if (!text.isNullOrBlank()) {
            if (looksUrlLike(text)) BlockRepo.isUrlBlocked(text)?.let { return it }
            if (scanContent) BlockRepo.checkContentTrigger(text)?.let { return it }
        }

        if (!desc.isNullOrBlank()) {
            if (looksUrlLike(desc)) BlockRepo.isUrlBlocked(desc)?.let { return it }
            if (scanContent) BlockRepo.checkContentTrigger(desc)?.let { return it }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                val result = inspectNodeHierarchy(child, depth + 1, scanContent)
                if (result != null) return result
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }

        return null
    }

    private fun isUrlViewId(viewId: String): Boolean {
        if (viewId.isBlank()) return false
        return BROWSER_URL_IDS.any { viewId == it || viewId.contains(it) } ||
            viewId.contains("url_bar") ||
            viewId.contains("omnibox") ||
            viewId.contains("location_bar") ||
            viewId.contains("search_box")
    }

    private fun looksUrlLike(value: String): Boolean {
        val v = value.trim().lowercase()
        return v.startsWith("http://") || v.startsWith("https://") ||
            (v.length in 4..300 && !v.contains(' ') && v.contains('.'))
    }

    private fun checkSettingsAntiBypass(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
        if (text.contains("freeyou") || desc.contains("freeyou")) return true

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (checkSettingsAntiBypass(child)) return true
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }
        return false
    }

    private fun trigger(target: String) {
        Log.w(TAG, "INTERCEPT TRIGGERED: $target")
        performGlobalAction(GLOBAL_ACTION_BACK)
        BlockInterventionCoordinator.trigger(this, target, source = "accessibility")
    }

    override fun onInterrupt() {
        Log.i(TAG, "FreeYou Accessibility Blocker interrupted.")
    }
}
