package com.freeyou.vpn

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.freeyou.AdultShieldUpdater
import com.freeyou.BlockInterventionCoordinator
import com.freeyou.MainActivity
import com.freeyou.R
import com.freeyou.data.BlockRepo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

class ShieldVpnService : VpnService() {
    companion object {
        private const val TAG = "FreeYouShieldVpn"
        private const val CHANNEL_ID = "freeyou_shield_vpn"
        private const val NOTIFICATION_ID = 1606
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val vpnScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var vpnLoopJob: Job? = null
    @Volatile private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        BlockRepo.init(this)
        AdultShieldUpdater.maybeRefresh(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopVpn()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (isRunning) return
        isRunning = true

        try {
            val builder = Builder()
                .setSession("FreeYou Shield")
                .addAddress("10.0.0.2", 32)
                .addDnsServer("10.0.0.1")
                .addRoute("10.0.0.1", 32)

            // Hard self-protection: FreeYou's own Gemini, updater and app traffic bypass the VPN.
            // This guarantees that the shield can never DNS-block the FreeYou application itself.
            try {
                builder.addDisallowedApplication(packageName)
            } catch (t: Throwable) {
                Log.w(TAG, "Could not exclude FreeYou from VPN: ${t.message}")
            }

            vpnInterface = builder.establish()
            if (vpnInterface == null) {
                isRunning = false
                stopSelf()
                return
            }

            vpnLoopJob = vpnScope.launch { runVpnLoop() }
            Log.i(TAG, "DNS shield started")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to start VPN: ${t.message}", t)
            isRunning = false
            stopSelf()
        }
    }

    private fun stopVpn() {
        isRunning = false
        vpnLoopJob?.cancel()
        vpnLoopJob = null
        try { vpnInterface?.close() } catch (_: Throwable) {}
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private suspend fun runVpnLoop() = withContext(Dispatchers.IO) {
        val pfd = vpnInterface ?: return@withContext
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32767)
        val realDnsIp = InetAddress.getByName("8.8.8.8")

        while (isRunning && isActive) {
            try {
                val length = input.read(buffer)
                if (length > 0) handlePacket(buffer, length, output, realDnsIp)
            } catch (t: Throwable) {
                if (isRunning) Log.d(TAG, "VPN read ended: ${t.message}")
            }
        }
    }

    private fun handlePacket(
        packet: ByteArray,
        length: Int,
        output: FileOutputStream,
        realDnsIp: InetAddress
    ) {
        try {
            val buffer = ByteBuffer.wrap(packet, 0, length)
            val versionAndIhl = buffer.get().toInt() and 0xFF
            val version = versionAndIhl ushr 4
            val ihl = versionAndIhl and 0x0F
            if (version != 4 || ihl < 5) return

            val ipHeaderLength = ihl * 4
            if (length < ipHeaderLength + 8) return

            buffer.position(9)
            val protocol = buffer.get().toInt() and 0xFF
            if (protocol != 17) return

            buffer.position(12)
            val srcIp = ByteArray(4)
            buffer.get(srcIp)
            val destIp = ByteArray(4)
            buffer.get(destIp)

            buffer.position(ipHeaderLength)
            val srcPort = buffer.short.toInt() and 0xFFFF
            val destPort = buffer.short.toInt() and 0xFFFF
            val udpLength = buffer.short.toInt() and 0xFFFF
            buffer.short // checksum

            if (destPort != 53) return

            val dnsPayloadLength = udpLength - 8
            if (dnsPayloadLength <= 0 || ipHeaderLength + 8 + dnsPayloadLength > length) return

            val dnsPayload = ByteArray(dnsPayloadLength)
            buffer.position(ipHeaderLength + 8)
            buffer.get(dnsPayload)

            val domain = DnsUtils.extractDomain(dnsPayload)
                .trim()
                .trimEnd('.')
                .lowercase()
            if (domain.isBlank()) return

            // IMPORTANT: use BlockRepo instead of only the hardcoded engine. This includes:
            // user rules + the dynamically downloaded 70K+ adult-domain database + heuristics.
            val blockedReason = BlockRepo.isUrlBlocked(domain)
            if (blockedReason != null) {
                val dnsResponsePayload = DnsUtils.createDnsBlockResponse(dnsPayload)
                sendUdpResponse(output, destIp, srcIp, 53, srcPort, dnsResponsePayload)
                BlockInterventionCoordinator.trigger(this, domain, source = "vpn-dns")
            } else {
                forwardDnsQuery(dnsPayload, output, destIp, srcIp, srcPort, realDnsIp)
            }
        } catch (t: Throwable) {
            Log.d(TAG, "Packet ignored: ${t.message}")
        }
    }

    private fun forwardDnsQuery(
        dnsPayload: ByteArray,
        output: FileOutputStream,
        tunDestIp: ByteArray,
        tunSrcIp: ByteArray,
        tunSrcPort: Int,
        realDnsIp: InetAddress
    ) {
        vpnScope.launch(Dispatchers.IO) {
            val dnsSocket = DatagramSocket()
            try {
                // Keep the upstream resolver socket outside the VPN to prevent loops.
                protect(dnsSocket)
                dnsSocket.soTimeout = 2_500

                dnsSocket.send(DatagramPacket(dnsPayload, dnsPayload.size, realDnsIp, 53))

                val inBuffer = ByteArray(4096)
                val inPacket = DatagramPacket(inBuffer, inBuffer.size)
                dnsSocket.receive(inPacket)

                val response = inBuffer.copyOfRange(0, inPacket.length)
                sendUdpResponse(output, tunDestIp, tunSrcIp, 53, tunSrcPort, response)
            } catch (t: Throwable) {
                Log.d(TAG, "Upstream DNS failed: ${t.message}")
            } finally {
                dnsSocket.close()
            }
        }
    }

    private fun sendUdpResponse(
        output: FileOutputStream,
        srcIp: ByteArray,
        destIp: ByteArray,
        srcPort: Int,
        destPort: Int,
        udpPayload: ByteArray
    ) {
        val totalLength = 20 + 8 + udpPayload.size
        val responsePacket = ByteArray(totalLength)
        val buffer = ByteBuffer.wrap(responsePacket)

        buffer.put(0x45.toByte())
        buffer.put(0x00.toByte())
        buffer.putShort(totalLength.toShort())
        buffer.putShort(0)
        buffer.putShort(0)
        buffer.put(64.toByte())
        buffer.put(17.toByte())
        buffer.putShort(0)
        buffer.put(srcIp)
        buffer.put(destIp)

        val ipChecksum = calculateChecksum(responsePacket, 0, 20)
        buffer.putShort(10, ipChecksum.toShort())

        buffer.position(20)
        buffer.putShort(srcPort.toShort())
        buffer.putShort(destPort.toShort())
        buffer.putShort((8 + udpPayload.size).toShort())
        buffer.putShort(0)
        buffer.put(udpPayload)

        try {
            synchronized(output) {
                output.write(responsePacket)
                output.flush()
            }
        } catch (t: Throwable) {
            Log.d(TAG, "Could not write DNS response: ${t.message}")
        }
    }

    private fun calculateChecksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0
        var i = offset
        while (i < offset + length - 1) {
            val word = ((data[i].toInt() and 0xFF) shl 8) or (data[i + 1].toInt() and 0xFF)
            sum += word
            i += 2
        }
        if (length % 2 != 0) {
            sum += (data[offset + length - 1].toInt() and 0xFF) shl 8
        }
        while ((sum shr 16) > 0) {
            sum = (sum and 0xFFFF) + (sum shr 16)
        }
        return sum.inv() and 0xFFFF
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FreeYou Shield",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "הגנת DNS פעילה"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): android.app.Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("FreeYou Shield פעיל")
            .setContentText("מסנן תכני 18+ ברמת DNS")
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    override fun onRevoke() {
        super.onRevoke()
        stopVpn()
    }

    override fun onDestroy() {
        isRunning = false
        vpnLoopJob?.cancel()
        try { vpnInterface?.close() } catch (_: Throwable) {}
        vpnInterface = null
        vpnScope.cancel()
        super.onDestroy()
    }
}
