package com.freeyou.vpn

import java.nio.ByteBuffer

object DnsUtils {
    fun extractDomain(dnsPayload: ByteArray): String {
        if (dnsPayload.size < 13) return ""
        return try {
            val buffer = ByteBuffer.wrap(dnsPayload)
            buffer.position(12)
            val labels = ArrayList<String>(8)

            while (buffer.hasRemaining()) {
                val len = buffer.get().toInt() and 0xFF
                if (len == 0) break

                // DNS compression pointers are not expected in the question name. Reject rather
                // than mis-parse a malformed packet.
                if ((len and 0xC0) != 0 || len > 63 || buffer.remaining() < len) return ""

                val label = ByteArray(len)
                buffer.get(label)
                labels.add(String(label, Charsets.UTF_8))
            }

            labels.joinToString(".")
        } catch (_: Throwable) {
            ""
        }
    }

    /**
     * Return a compact NXDOMAIN response instead of appending a fake A record.
     * This works for A and AAAA queries and stays valid when the request contains EDNS/OPT data.
     */
    fun createDnsBlockResponse(request: ByteArray): ByteArray {
        if (request.size < 12) return request.copyOf()

        val response = request.copyOf()

        // Preserve RD/opcode from the request, set QR=1 (response).
        response[2] = (response[2].toInt() or 0x80).toByte()
        // Preserve upper response flags where sensible, advertise recursion available, RCODE=3 NXDOMAIN.
        response[3] = (((response[3].toInt() and 0x70) or 0x80 or 0x03) and 0xFF).toByte()

        // ANCOUNT = 0, NSCOUNT = 0. Preserve ARCOUNT so an EDNS OPT record remains well-formed.
        response[6] = 0
        response[7] = 0
        response[8] = 0
        response[9] = 0

        return response
    }
}
