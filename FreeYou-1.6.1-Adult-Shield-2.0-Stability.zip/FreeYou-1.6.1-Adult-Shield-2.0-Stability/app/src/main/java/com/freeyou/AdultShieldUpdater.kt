package com.freeyou

import android.content.Context
import android.util.Log
import com.freeyou.data.BlockRepo

/**
 * Keeps the local adult-domain database fresh without making browsing depend on the network.
 * The existing downloaded database remains usable while an update is unavailable.
 */
object AdultShieldUpdater {
    private const val TAG = "FreeYouAdultUpdater"
    private const val PREFS = "freeyou_adult_shield_updater_v1"
    private const val KEY_LAST_SUCCESS = "last_success"
    private const val KEY_LAST_ATTEMPT = "last_attempt"

    private const val REFRESH_INTERVAL_MS = 24L * 60L * 60L * 1000L
    private const val RETRY_INTERVAL_MS = 60L * 60L * 1000L
    private const val MIN_EXPECTED_DOMAINS = 20_000

    private const val PRIMARY_URL =
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn-only/hosts"
    private const val FALLBACK_URL =
        "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn/hosts"

    @Volatile
    private var inFlight = false

    @Synchronized
    fun maybeRefresh(context: Context, force: Boolean = false) {
        if (inFlight) return

        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastSuccess = prefs.getLong(KEY_LAST_SUCCESS, 0L)
        val lastAttempt = prefs.getLong(KEY_LAST_ATTEMPT, 0L)

        if (!force && now - lastSuccess < REFRESH_INTERVAL_MS) return
        if (!force && now - lastAttempt < RETRY_INTERVAL_MS) return

        inFlight = true
        prefs.edit().putLong(KEY_LAST_ATTEMPT, now).apply()

        Thread {
            try {
                BlockRepo.init(appContext)

                var count = BlockRepo.updateBlocklist(PRIMARY_URL)
                if (count < MIN_EXPECTED_DOMAINS) {
                    Log.w(TAG, "Primary adult list unexpectedly small ($count), trying fallback")
                    count = BlockRepo.updateBlocklist(FALLBACK_URL)
                }

                if (count >= MIN_EXPECTED_DOMAINS) {
                    prefs.edit().putLong(KEY_LAST_SUCCESS, System.currentTimeMillis()).apply()
                    Log.i(TAG, "Adult-domain list refreshed: $count domains")
                } else {
                    Log.w(TAG, "Adult-domain update rejected as too small: $count")
                }
            } catch (t: Throwable) {
                Log.w(TAG, "Adult-domain update failed; keeping local protection: ${t.message}")
            } finally {
                inFlight = false
            }
        }.apply {
            name = "FreeYou-AdultShield-Updater"
            isDaemon = true
            start()
        }
    }
}
