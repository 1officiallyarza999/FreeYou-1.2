package com.freeyou.data

import java.util.Locale

object AdultBlockEngine {

    val MAJOR_ADULT_DOMAINS = hashSetOf(
        "pornhub.com", "pornhubpremium.com", "xvideos.com", "xvideos2.com", "xnxx.com", "xnxx2.com",
        "xhamster.com", "xhamster.desi", "xhamster2.com", "xhamsterlive.com",
        "redtube.com", "youporn.com", "brazzers.com", "bangbros.com", "realitykings.com",
        "naughtyamerica.com", "mofos.com", "twistys.com", "digitalplayground.com", "rk.com",
        "onlyfans.com", "fansly.com", "fapello.com", "coomer.party", "coomer.su", "kemono.party",
        "kemono.su", "manyvids.com", "loyalfans.com", "fanvue.com", "mym.fans", "clips4sale.com",
        "iwantclips.com", "modelhub.com", "admireme.vip", "justforfans.com", "pocketstars.com",
        "chaturbate.com", "stripchat.com", "bongacams.com", "livejasmin.com", "camsoda.com",
        "cam4.com", "flirt4free.com", "myfreecams.com", "streamate.com", "imlive.com",
        "camversity.com", "xcams.com", "babestation.tv",
        "spankbang.com", "eporner.com", "hqporner.com", "beeg.com", "tube8.com", "fuq.com",
        "erome.com", "pornmd.com", "daftsex.com", "porndig.com", "txxx.com", "tubez.com",
        "drtuber.com", "nuvid.com", "shemale.xxx", "tnaflix.com", "empflix.com", "slutload.com",
        "sunporno.com", "pornrabbit.com", "pornsharing.com", "severeporn.com", "tubeoffline.com",
        "4tube.com", "fux.com", "porntube.com", "pornbox.com", "lubetube.com", "badjojo.com",
        "heavy-r.com", "motherless.com", "tblop.com", "freeomovie.com", "pornve.com",
        "pornone.com", "gotporn.com", "upornia.com", "porngo.com", "alphaporno.com",
        "onlyjerk.com", "onlyjerk.org", "onlyjerk.net",
        "nhentai.net", "tsumino.com", "hitomi.la", "hanime.tv", "rule34.xxx", "rule34.paheal.net",
        "gelbooru.com", "danbooru.donmai.us", "e-hentai.org", "exhentai.org", "hentaihaven.xxx",
        "hentaihaven.me", "fakku.net", "asmhentai.com", "simply-hentai.com", "luscious.net",
        "furaffinity.net", "e621.net", "pururin.io", "doujins.com", "hentai2read.com",
        "adultfriendfinder.com", "ashleymadison.com", "fetlife.com", "alt.com", "passion.com",
        "fling.com", "casualx.badpuppy.com", "benaughty.com", "kasidie.com", "sdc.com",
        "literotica.com", "lushstories.com", "bdsmlr.com", "vipergirls.to", "imagefap.com",
        "vintage-erotica-forum.com", "planetsuzy.org", "cyberdrop.me", "bunkr.is", "bunkr.ru"
    )

    /** High-confidence substrings only. Keep short/generic words out to avoid false positives. */
    private val HIGH_CONFIDENCE_HOST_SUBSTRINGS = listOf(
        "pornhub", "xvideos", "xnxx", "xhamster", "onlyfans", "fansly", "fapello",
        "coomer", "kemono", "chaturbate", "stripchat", "camsoda", "bongacams",
        "livejasmin", "redtube", "youporn", "brazzers", "bangbros", "rule34",
        "nhentai", "erome", "spankbang", "eporner", "hqporner", "daftsex",
        "xhamsterlive", "onlyjerk", "jerkmate", "hentai", "nsfw", "sexcam",
        "sexvid", "sexvideo", "adultwebcam", "porno", "porn", "xxx", "erotic",
        "blowjob", "dildo", "literotica"
    )

    /** Generic explicit words are safe only when they are complete hostname labels. */
    private val EXPLICIT_HOST_TOKENS = setOf(
        "sex", "anal", "milf", "nude", "nudes", "boobs", "pussy", "shemale", "adult"
    )

    val ADULT_TLDS = listOf(".xxx", ".porn", ".adult", ".sex", ".sexy")

    val STRICT_CONTENT_TRIGGERS = listOf(
        "onlyfans", "only fans", "אונליפאנס", "אונלי פאנס", "fansly", "fapello", "onlyjerk",
        "leaked onlyfans", "onlyfans leak", "onlyfans free",
        "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "brazzers",
        "chaturbate", "stripchat", "rule34", "nhentai", "erome", "spankbang",
        "פורנו", "סרטי סקס", "סרטוני סקס", "אתרי סקס", "הורדות סקס", "סקס ישראלי",
        "תמונות עירום", "עירום מלא", "נערות ליווי", "זיונים", "זיון", "הנטאי", "סרטון סקס",
        "תוכן למבוגרים בלבד",
        "free porn", "porn video", "porn videos", "watch porn", "hd porn", "hardcore porn",
        "hardcore sex", "sex video", "sex videos", "adult videos", "explicit videos",
        "sex cam", "cam girl", "nudes in bio", "link in bio 🔞", "dm for nudes",
        "send nudes", "leaked nudes", "uncensored nudes", "full nude"
    )

    private val SEXUAL_TERMS = listOf(
        "nude", "nudes", "naked", "hardcore", "explicit", "xxx", "hentai", "erotic",
        "blowjob", "anal sex", "oral sex", "camgirl", "cam girl", "adult model",
        "עירום", "אירוטי", "אירוטית", "סקס", "מצלמות סקס"
    )

    private val ADULT_PAGE_CUES = listOf(
        "18+", "18 +", "adults only", "adult content", "age verification", "confirm your age",
        "watch full video", "watch free", "free videos", "uncensored", "leaked", "premium videos",
        "live cams", "live cam", "explicit content", "תוכן 18+", "למבוגרים בלבד", "אימות גיל"
    )

    private val MEDIA_CUES = listOf(
        "videos", "photos", "gallery", "models", "clips", "stream",
        "סרטונים", "תמונות", "גלריה", "דוגמניות"
    )

    fun isUrlOrHostBlocked(rawUrl: String): String? {
        val trimmed = rawUrl.trim().lowercase(Locale.ROOT)
        if (trimmed.isEmpty()) return null

        val hostPart = extractHost(trimmed)
        if (hostPart.isEmpty()) return null

        if (MAJOR_ADULT_DOMAINS.contains(hostPart)) return hostPart

        var sub = hostPart
        while (sub.contains('.')) {
            sub = sub.substringAfter('.')
            if (MAJOR_ADULT_DOMAINS.contains(sub)) return hostPart
        }

        if (ADULT_TLDS.any { hostPart.endsWith(it) }) return hostPart

        if (HIGH_CONFIDENCE_HOST_SUBSTRINGS.any { hostPart.contains(it) }) return hostPart

        val hostTokens = hostPart.split('.', '-', '_').filter { it.isNotBlank() }
        if (hostTokens.any { it in EXPLICIT_HOST_TOKENS }) return hostPart

        val normalizedFull = trimmed
            .replace("+", " ")
            .replace("%20", " ")
            .replace("%2b", "+")

        for (trigger in STRICT_CONTENT_TRIGGERS) {
            if (normalizedFull.contains(trigger)) return trigger
        }

        return null
    }

    private fun extractHost(raw: String): String {
        return raw
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore('/')
            .substringBefore('?')
            .substringBefore('#')
            .substringBefore(':')
            .removePrefix("www.")
            .trim()
    }

    /**
     * Local sexual-content classifier for visible Accessibility text.
     * It first checks high-confidence phrases, then combines independent weaker signals.
     */
    fun checkScreenText(text: CharSequence?): String? {
        if (text.isNullOrBlank()) return null
        val clean = text.toString().lowercase(Locale.ROOT).trim().take(20_000)

        for (trigger in STRICT_CONTENT_TRIGGERS) {
            if (clean.contains(trigger)) return trigger
        }

        val collapsed = clean
            .replace(" ", "")
            .replace(".", "")
            .replace("-", "")
            .replace("_", "")

        val collapsedBrands = listOf(
            "onlyfans", "אונליפאנס", "pornhub", "xvideos", "xnxx", "xhamster", "onlyjerk"
        )
        for (brand in collapsedBrands) {
            if (collapsed.contains(brand)) return brand
        }

        val sexualSignals = SEXUAL_TERMS.filter { clean.contains(it) }.toSet()
        val adultSignals = ADULT_PAGE_CUES.filter { clean.contains(it) }.toSet()
        val mediaSignals = MEDIA_CUES.filter { clean.contains(it) }.toSet()

        val sexualHits = sexualSignals.size.coerceAtMost(3)
        val adultCueHits = adultSignals.size.coerceAtMost(2)
        val mediaHits = mediaSignals.size.coerceAtMost(1)
        val score = sexualHits * 2 + adultCueHits * 2 + mediaHits

        return if (score >= 6 && sexualHits >= 1 && (adultCueHits >= 1 || sexualHits >= 2)) {
            "sexual-content:${sexualSignals.firstOrNull() ?: "18+"}"
        } else {
            null
        }
    }
}
