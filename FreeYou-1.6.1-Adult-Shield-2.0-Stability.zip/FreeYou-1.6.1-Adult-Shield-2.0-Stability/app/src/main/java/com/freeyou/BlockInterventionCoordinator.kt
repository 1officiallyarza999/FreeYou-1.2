package com.freeyou

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import com.freeyou.data.BlockRepo

/**
 * One intervention path for every shield source: Accessibility, VPN/DNS and future classifiers.
 * The global cooldown is deliberate: a single adult page can resolve many blocked subdomains at once.
 */
object BlockInterventionCoordinator {
    private const val TAG = "FreeYouIntervention"
    private const val GLOBAL_COOLDOWN_MS = 12_000L
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var lastTriggerAt = 0L

    @Synchronized
    fun trigger(context: Context, target: String, source: String = "unknown") {
        val now = System.currentTimeMillis()

        // If the mentor overlay is already visible, the intervention is already in progress.
        // Never count DNS subresources as new attempts while the user is handling the first one.
        if (MentorOverlay.isShowing()) return
        if (now - lastTriggerAt < GLOBAL_COOLDOWN_MS) return
        lastTriggerAt = now

        val appContext = context.applicationContext
        val normalizedTarget = target.trim().ifEmpty { "18+ content" }
        mainHandler.post {
            performIntervention(appContext, normalizedTarget, source)
        }
    }

    private fun performIntervention(context: Context, target: String, source: String) {
        BlockRepo.init(context)
        val count = BlockRepo.bumpAttempt()
        val nextRoute = if (count <= 1) "journal" else "mission"
        BlockRepo.setPendingRoute(nextRoute, target, count)

        Log.w(TAG, "Blocked target=$target source=$source attempt=$count")

        if (Settings.canDrawOverlays(context) && !MentorOverlay.isShowing()) {
            MentorOverlay.show(
                context,
                count,
                onContinue = { launchApp(context, nextRoute, target, count) },
                onBack = { goHome(context) }
            )
        }

        // Best effort. Android may restrict some background activity launches; in that case the
        // overlay remains the safe user-driven route into FreeYou.
        launchApp(context, "intercept", target, count)
    }

    private fun launchApp(context: Context, route: String, target: String, count: Int) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra("freeyou_route", route)
                putExtra("freeyou_target", target)
                putExtra("freeyou_count", count)
            }
            context.startActivity(intent)
        } catch (t: Throwable) {
            Log.w(TAG, "Could not launch intercept activity: ${t.message}")
        }
    }

    private fun goHome(context: Context) {
        try {
            val home = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(home)
        } catch (t: Throwable) {
            Log.w(TAG, "Could not open launcher: ${t.message}")
        }
    }
}
