# FreeYou 1.6.1 Stability Audit

## Critical issues found and fixed

1. `anal` was used as a raw hostname substring. This could classify benign domains such as `google-analytics.com` as adult. Fixed with high-confidence substrings + exact hostname tokens.
2. The VPN's blocked DNS response appended an A record after the full request. Requests containing EDNS/OPT could become malformed, and AAAA queries were handled incorrectly. Fixed by returning a protocol-safe NXDOMAIN response.
3. VPN and Accessibility could both fire for one page, and multiple blocked subdomains could each count as separate attempts. Fixed with one global cooldown and overlay guard.
4. FreeYou did not explicitly exclude its own traffic from the VPN. Added `Builder.addDisallowedApplication(packageName)`.
5. Accessibility already skipped matching package events, but self-protection is now explicit and performed before repository/content checks on both event and root node package.
6. Full content scoring ran too broadly. It is now limited to browser/social contexts or UI trees that clearly expose a URL bar.
7. VPN service exposure was broader than needed. `android:exported` is now false.
8. Recursive accessibility aggregation did not recycle child nodes. Fixed.

## Known technical limits (not regressions)

- DNS interception currently focuses on IPv4 UDP/53. DoH/DoT, TCP DNS, IPv6-only paths and image-only adult content need additional layers.
- OEM background restrictions can affect foreground services differently; Samsung/Pixel/Xiaomi device tests are recommended.
- Background activity-launch restrictions vary by Android version; the overlay is retained as the user-driven fallback.
