# FreeYou 1.6.1 — Adult Shield 2.0 Stability Hotfix

This patch targets the current `1officiallyarza999/FreeYou-1.2` Android project.

## Stability fixes in 1.6.1

- Hard self-protection in Accessibility: events and node trees from FreeYou's own runtime package are skipped before any content/app blocking logic.
- Hard self-protection in VPN: `addDisallowedApplication(packageName)` keeps FreeYou's own Gemini, updater and app traffic outside the VPN tunnel.
- VPN service is no longer exported to other apps.
- Replaced unsafe fake-A DNS blocking with NXDOMAIN responses, which work for both A/AAAA and do not corrupt EDNS/OPT queries.
- Added a global intervention cooldown and overlay guard so one page with many blocked DNS subdomains cannot increment attempts or launch multiple mentor screens.
- Removed dangerous substring false positives such as `anal` matching `google-analytics.com`; generic explicit terms now require complete hostname tokens.
- Deep sexual-content scoring is scoped to browsers/social apps or apps that expose a URL bar, reducing false positives in settings, banking, health and unrelated apps.
- Accessibility child nodes are recycled in recursive scans to reduce churn/leaks.
- OnlyJerk recognition and the large dynamic adult-domain list remain enabled.
- Version: `versionCode = 17`, `versionName = 1.6.1`.

## Files to copy over the repository

Copy the `app/` directory over the existing repository while preserving paths.

New files:
- `app/src/main/java/com/freeyou/AdultShieldUpdater.kt`
- `app/src/main/java/com/freeyou/BlockInterventionCoordinator.kt`

Replaced files:
- `app/src/main/java/com/freeyou/data/AdultBlockEngine.kt`
- `app/src/main/java/com/freeyou/BlockerAccessibilityService.kt`
- `app/src/main/java/com/freeyou/vpn/ShieldVpnService.kt`
- `app/src/main/java/com/freeyou/vpn/DnsUtils.kt`
- `app/src/main/AndroidManifest.xml`
- `app/build.gradle.kts`

## Device smoke test before calling this release stable

1. Install over the existing APK.
2. Open FreeYou and move through Home, Shield, Mentor, Build/Grow and Settings while Accessibility + VPN are active. FreeYou must never intercept itself.
3. Test normal sites that use analytics/CDNs (Google, GitHub, news sites, YouTube). They must load without FreeYou intervention.
4. Test a known adult site and a lesser-known adult site such as OnlyJerk. They should be blocked and open exactly one intervention flow.
5. Wait on the intervention screen for 15+ seconds and confirm it does not relaunch repeatedly from DNS subresources.
6. Test first attempt -> journal; later attempt -> mission.
7. Disable network and confirm the local blocklist/heuristics still work for already-known domains.

## What was validated in this patch workspace

- `AdultBlockEngine.kt` compiled with Kotlin 2/JVM and passed a benign/adult hostname test matrix.
- `DnsUtils.kt` compiled with Kotlin/JVM and passed DNS extraction + NXDOMAIN response checks.
- AndroidManifest.xml parsed as valid XML.
- Static self-protection assertions passed for Accessibility own-package skip, VPN own-package bypass, non-exported VPN service and global intervention debounce.

## Important

No static audit can prove zero runtime bugs across every Android/OEM/browser. The GitHub CI build and real-device smoke test above are still required before release. This patch specifically removes the highest-risk self-blocking, false-positive and repeated-trigger problems found during review.
