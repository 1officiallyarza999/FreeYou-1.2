# מיזוג — FreeYou 1.3

הפרויקט במאגר (Kotlin + Compose) הוא הבסיס. הוא כבר טוב יותר מגרסת
ה-React Native שלי בכמה מקומות, אז לא בניתי דבר מחדש. שישה קבצים בלבד.

## שלושה קבצים חדשים — העתק פנימה

| קובץ | ליעד |
|---|---|
| `ScanPolicy.kt` | `app/src/main/java/com/freeyou/data/` |
| `MentorTone.kt` | `app/src/main/java/com/freeyou/data/` |
| `ElevenLabsTTSProvider.kt` | `app/src/main/java/com/freeyou/ai/` |

## שלושה קבצים קיימים — דרוס בגרסה שכאן

| קובץ | מה שונה |
|---|---|
| `BlockerAccessibilityService.kt` | מפעיל את `ScanPolicy` על כל החלון |
| `data/BlockRepo.kt` | שדה `scanMessaging` + `setScanMessaging()` |
| `ai/MentorManager.kt` | בוחר בין ElevenLabs לקול המובנה |

---

## מה כבר היה במאגר ולא נגעתי בו

חסימת כתובות ב-12 דפדפנים · `ShieldVpnService` לסינון DNS ·
מניעת עקיפה דרך הגדרות נגישות · Room · `MentorOverlay` ·
שכבת ה-AI המופשטת · המסכים ב-Compose · מצב לילה ואימות GPS ·
`AdultBlockEngine` עם רשימת המונחים.

הרשימה הזו טובה, ולכן `ScanPolicy` **משתמש בה** ולא כותב אחת חדשה.

---

## מה נוסף, ולמה

### 1. ניקוד לסריקת המסך — `ScanPolicy.kt`

הזרימה הקודמת התריעה על הצומת הראשון שהכיל מונח. זה נכון לאתר תוכן,
ושגוי לכתבה בעיתון על התעשייה, לעמוד רפואי, או לשיחה שבה מישהו ציטט מילה.

עכשיו: ניקוד על כל החלון, רף של 7 נקודות ולפחות שני מונחים שונים.
מונחים דו-משמעיים (`18+`, `עירום`) שווים פחות. **התראת שווא אחת בשבוע
הראשון והמשתמש מוחק את האפליקציה — ואז הוא בלי הגנה בכלל.**

בנוסף:
- **אפליקציות שלא נסרקות לעולם:** בנקאות, מנהלי סיסמאות, בריאות.
- **אפליקציות הודעות כבויות כברירת מחדל.** שם מתנהלות השיחות הפרטיות
  שלך. יש מתג — `BlockRepo.setScanMessaging(true)` — וזו בחירה מודעת שלך.
- **השהיה 1.5 שניות וקירור 40 שניות.** בלי זה זה רץ על כל שינוי פיקסל.
- **הניקוד לא נשמר, לא ללוג, לא לרשת.** מוחזר מספר, לא טקסט.

חיפוש מפורש בשורת הכתובת נשאר טריגר ישיר — שם הכוונה מפורשת.

### 2. שלוש רמות טון — `MentorTone.kt`

`brother` אח גדול · `coach` מאמן · `hard` קשוח.
הרמה החמה מנותבת ל-`MentorLines` הקיים ולא הועתקה.

**הקו שלא נחצה בשום רמה:** קשה על התירוץ, לא על האדם.
"אתה חלש" מייצר בושה, ובושה היא המנבא החזק ביותר לנפילה הבאה.
לכן גם ברמה הקשוחה הוא מדבר על הדחף בגוף שלישי ועל הגבר בגוף ראשון רבים.

חיבור למסך העצירה:
```kotlin
MentorToneEngine.interceptLine(
    MentorTone.from(BlockRepo.state.value.mentorMode),
    MentorContext(reasons, days, attempt, hour),
    byScan = target == "תוכן על המסך"
)
```

### 3. קול אמיתי — `ElevenLabsTTSProvider.kt`

מממש את ממשק `TTSProvider` הקיים, כך ש-`MentorManager` לא יודע מי מדבר.
משתמש ב-OkHttp שכבר בתלויות.

- **קאש מקומי:** `warmCache()` מייצר מראש את כל בנק המשפטים כ-mp3.
  ברגע העצירה הקול מתנגן מיד, גם בלי קליטה.
- **סדר נפילה:** קאש ← רשת ← TTS מובנה. אף פעם לא שותק ברגע העצירה.
- ה-`mode` שכבר עובר ב-`speak(text, mode)` הוא הטון, ומשנה
  stability, style ו-speed.

---

## שני צעדים שנשארו לך

### 1. קול
ב-`MentorManager.kt` מלא את `ELEVEN_VOICE_ID`. קח קול מה-Voice Library
(סנן Hebrew + Male + Deep) — **לא קול דיפולטיבי**, הם יורדים מהאוויר
ב-31.12.2026 ואינם זמינים לחשבונות שנפתחו אחרי מרץ 2026.
הכי טוב: שכפל קול משלך ב-Instant Voice Cloning, ואז היצר הטוב
מדבר בקול שלך.

### 2. פרוקסי
מפתח API בתוך APK מחלצים בשתי דקות. Cloudflare Worker:

```js
export default {
  async fetch(req, env) {
    const b = await req.json();
    const r = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${b.voice_id}`,
      {method:'POST',
       headers:{'xi-api-key':env.ELEVEN_KEY,'content-type':'application/json'},
       body: JSON.stringify({text:b.text, model_id:b.model_id,
                             voice_settings:b.voice_settings})});
    return new Response(r.body, {headers:{'content-type':'audio/mpeg'}});
  },
};
```
`wrangler secret put ELEVEN_KEY`, ואז עדכן את `ELEVEN_PROXY_URL`.

---

## הבנייה

התיקון ל-`debug.keystore` שנתתי קודם עדיין נדרש ב-workflow.
בלעדיו הבנייה נופלת בשלב האחרון בדיוק כמו בלוג ששלחת.
