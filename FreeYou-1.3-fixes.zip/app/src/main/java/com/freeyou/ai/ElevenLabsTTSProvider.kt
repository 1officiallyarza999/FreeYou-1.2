package com.freeyou.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import com.freeyou.data.MentorTone
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * הקול האמיתי של היצר הטוב.
 *
 * מממש את ממשק TTSProvider הקיים, כך שאפשר להחליף בין הקולות
 * בלי לגעת ב-MentorManager — הוא לא יודע מי מדבר.
 *
 * ===== למה יש קאש מקומי =====
 * ברגע החסימה אין זמן להמתין לרשת. לכן warmCache() מייצר מראש
 * את כל בנק המשפטים כקבצי mp3. מאותו רגע הקול ברגע העצירה
 * מתנגן מיד — גם בלי קליטה.
 *
 * ===== סדר הנפילה =====
 *   קאש -> רשת -> AndroidTTSProvider.
 * האפליקציה אף פעם לא שותקת ברגע העצירה.
 */
class ElevenLabsTTSProvider(
    private val context: Context,
    private val proxyUrl: String,
    private val voiceId: String,
    private val fallback: TTSProvider,
) : TTSProvider {

    private val http = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private val scope = CoroutineScope(Dispatchers.IO)
    private var player: MediaPlayer? = null

    private val dir: File by lazy { File(context.filesDir, "voice").apply { mkdirs() } }

    private fun path(text: String, tone: String) =
        File(dir, "${(tone + "|" + text).hashCode().toString(36)}.mp3")

    /** ההגדרות שקובעות כמה אסרטיבי הוא יישמע */
    private fun settings(tone: String): JSONObject = when (tone) {
        MentorTone.BROTHER.key -> json(0.55, 0.80, 0.25, 0.96)  // חם, יציב, לא ממהר
        MentorTone.HARD.key    -> json(0.30, 0.85, 0.70, 1.06)  // קצר, נחתך, בלי ריכוך
        else                   -> json(0.42, 0.82, 0.45, 1.00)  // ישיר, קצוב
    }

    private fun json(stab: Double, sim: Double, style: Double, speed: Double) = JSONObject()
        .put("stability", stab)
        .put("similarity_boost", sim)
        .put("style", style)
        .put("speed", speed)

    override fun speak(text: String, mode: String) {
        if (text.isBlank()) return
        val f = path(text, mode)
        if (f.exists()) { play(f); return }

        // אין קליפ מוכן: מדבר עכשיו במנוע המקומי, ומכין קליפ לפעם הבאה
        fallback.speak(text, mode)
        scope.launch { fetch(text, mode) }
    }

    override fun stop() {
        player?.run { if (isPlaying) stop(); release() }
        player = null
        fallback.stop()
    }

    override fun shutdown() {
        stop()
        fallback.shutdown()
    }

    private fun play(f: File) {
        stop()
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            setDataSource(f.absolutePath)
            setOnCompletionListener { it.release(); player = null }
            prepare()
            start()
        }
    }

    private fun fetch(text: String, tone: String): File? {
        if (voiceId.isBlank() || proxyUrl.isBlank()) return null
        return try {
            val body = JSONObject()
                .put("voice_id", voiceId)
                // flash: השהיה נמוכה, מה שצריך לשיחה חיה
                .put("model_id", "eleven_flash_v2_5")
                .put("text", text)
                .put("voice_settings", settings(tone))
                .toString()
                .toRequestBody("application/json".toMediaType())

            val res = http.newCall(Request.Builder().url(proxyUrl).post(body).build()).execute()
            res.use {
                if (!it.isSuccessful) return null
                val bytes = it.body?.bytes() ?: return null
                if (bytes.size < 512) return null
                val f = path(text, tone)
                f.writeBytes(bytes)
                f
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * מריצים פעם אחת אחרי ההתקנה, על wifi.
     * אחרי זה רגע העצירה תמיד מיידי ותמיד בקול האמיתי.
     */
    fun warmCache(lines: List<String>, tone: String, onProgress: ((Int, Int) -> Unit)? = null) {
        scope.launch {
            lines.forEachIndexed { i, l ->
                if (!path(l, tone).exists()) fetch(l, tone)
                onProgress?.invoke(i + 1, lines.size)
            }
        }
    }

    fun cachedCount(): Int = dir.listFiles()?.size ?: 0
}
