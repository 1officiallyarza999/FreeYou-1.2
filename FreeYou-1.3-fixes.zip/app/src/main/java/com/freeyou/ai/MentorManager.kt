package com.freeyou.ai

import android.content.Context
import com.freeyou.data.BlockRepo
import com.freeyou.data.NetworkUtils
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatMessage(val isMentor: Boolean, val text: String, val role: String)

/** מה שהוא אומר כשהכל נופל. הוא אף פעם לא שותק. */
private const val FALLBACK_LINE =
    "אין לי חיבור כרגע, אבל אני עדיין כאן. קום, מים קרים על הפנים, וחמש דקות אוויר. " +
    "זה מה שהייתי אומר לך גם עם חיבור.

class MentorManager(private val context: Context) {
    /**
     * הסיבה לקריסה: CoroutineScope(Dispatchers.Main) עם Job רגיל ובלי
     * מטפל שגיאות. כל חריגה בתוך scope.launch — רשת, הרשאה חסרה,
     * מנוע דיבור שלא אותחל — הפילה את האפליקציה כולה.
     * SupervisorJob מבודד את הכשל, וה-handler הופך אותו להודעה.
     */
    private val errorHandler = CoroutineExceptionHandler { _, e ->
        _isProcessing.value = false
        val msg = _messages.value.toMutableList()
        msg.add(ChatMessage(true, FALLBACK_LINE, "mentor"))
        _messages.value = msg
    }
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() + errorHandler)
    
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages
    
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening
    
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private var ttsProvider: TTSProvider? = null
    private var sttProvider: STTProvider? = null
    
    private val onlineLlm = GeminiLLMProvider()
    
    var speechEnabled = true
    var activeMode = "coach"
        set(value) {
            if (field == value) return          // בלי זה: הודעת פתיחה כפולה והקראה כפולה
            field = value
            addWelcomeMessage()
        }

    init {
        ttsProvider = AndroidTTSProvider(context)
        sttProvider = AndroidSTTProvider(context)
        addWelcomeMessage()
    }

    private fun addWelcomeMessage() {
        val welcomeLine = when (activeMode) {
            "warrior" -> "אני היצר הטוב שלך. בלי תירוצים ובלי בריחות. אנחנו כאן כדי לנצח ולבנות גבר חזק. דבר אליי."
            "compassion" -> "שלום אחי. שום דבר שאתה עובר כאן אינו מביך או חריג. המרחב הזה בטוח, ואני כאן כדי לתמוך בך בכל רגע."
            else -> "שלום אלוף. אני כאן כדי לחדד אותך, להזכיר לך את היעדים שלך ולפרק כל דחף או מכשול בדרך. איך אני יכול לעזור עכשיו?"
        }
        _messages.value = listOf(ChatMessage(true, welcomeLine, "mentor"))
        speak(welcomeLine)
    }

    fun speak(text: String) {
        if (speechEnabled) {
            ttsProvider?.speak(text, activeMode)
        }
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return
        
        val currentMsgs = _messages.value.toMutableList()
        currentMsgs.add(ChatMessage(false, userText, "user"))
        _messages.value = currentMsgs
        
        _isProcessing.value = true
        
        val history = currentMsgs.map { Pair(it.role, it.text) }
        
        scope.launch {
            val replyText = try { withContext(Dispatchers.IO) {
                // Determine whether to use online or offline engine
                val isOnline = runCatching { NetworkUtils.isInternetAvailable(context) }.getOrDefault(false)
                
                val provider: LLMProvider = if (isOnline) {
                    onlineLlm
                } else {
                    val reasons = BlockRepo.state.value.reasons
                    val days = BlockRepo.daysClean()
                    OfflineMentorEngine(reasons, days)
                }
                
                val systemPrompt = buildSystemPrompt()
                provider.generateReply(systemPrompt, history, userText)
            } } catch (e: Exception) {
                // אין רשת, אין מפתח, או שהשרת נפל — הוא עדיין אומר משהו
                FALLBACK_LINE
            }
            
            val newMsgs = _messages.value.toMutableList()
            newMsgs.add(ChatMessage(true, replyText, "mentor"))
            _messages.value = newMsgs
            _isProcessing.value = false
            
            speak(replyText)
        }
    }

    private fun buildSystemPrompt(): String {
        val days = BlockRepo.daysClean()
        val reasons = BlockRepo.state.value.reasons
        val reasonsStr = if (reasons.isNotEmpty()) "סיבות מרכזיות של המשתמש: ${reasons.joinToString(", ")}" else ""
        
        val modeInstructions = when (activeMode) {
            "warrior" -> "התנהג כלוחם: חד, קצר, אנרגטי, לא משפיל. תן פקודות פיזיות כדי לעורר אותו."
            "compassion" -> "התנהג בחמלה: רגוע, תומך, ללא ביקורת, מעודד נשימות ומנוחה."
            else -> "התנהג כמאמן (Coach): פרקטי, ממוקד, ניתוח המצב, מציע אלטרנטיבות בריאות."
        }
        
        return """
            אתה "היצר הטוב שלו", העוזר האישי של המשתמש באפליקציית FreeYou נגד התמכרויות והרגלים רעים (בעיקר צפייה בפורנו וגלילה אינסופית).
            מצב נוכחי: המשתמש נקי $days ימים.
            $reasonsStr
            
            כללי התנהגות קריטיים:
            1. $modeInstructions
            2. המסר שלך קצר, מדויק וברור. עד 3 משפטים קצרים בכל תגובה.
            3. ענה בעברית בלבד. בלי פסקאות ארוכות מדי כי זה הולך להיות מוקרא ב-Text to Speech.
            4. אל תהיה מטיף דת, אל תשפוט אותו, אל תשפיל אותו. עזור לו לקבל החלטה נכונה ברגע של דחף.
            5. עודד אותו לעשות פעולה עכשיו: שכיבות סמיכה, כוס מים, לצאת החוצה, לנשום עמוק.
        """.trimIndent()
    }

    fun startListening() {
        sttProvider?.startListening(
            onResult = { text ->
                if (!text.isNullOrBlank()) {
                    sendMessage(text)
                }
            },
            onStatus = { active ->
                _isListening.value = active
            }
        )
    }

    fun stopListening() {
        sttProvider?.stopListening()
    }

    fun destroy() {
        // runCatching: מנוע דיבור שלא הספיק לאתחל זרק כאן וקרס בזמן יציאה מהמסך.
        runCatching { ttsProvider?.shutdown() }
        runCatching { sttProvider?.destroy() }
        _isListening.value = false
        _isProcessing.value = false
        scope.cancel()   // בלי זה תשובה שחוזרת אחרי סגירת המסך כותבת ל-state מת
    }
}
