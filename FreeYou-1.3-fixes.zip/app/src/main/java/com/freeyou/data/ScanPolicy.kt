package com.freeyou.data

import android.os.SystemClock
import android.view.accessibility.AccessibilityNodeInfo

/**
 * שכבת מדיניות מעל סריקת המסך הקיימת.
 *
 * AdultBlockEngine.STRICT_CONTENT_TRIGGERS כבר מכיל את רשימת המונחים —
 * הקובץ הזה לא מכפיל אותה, הוא רק מחליט מתי מותר להתריע עליה.
 *
 * ===== למה זה נחוץ =====
 * הזרימה הקיימת מתריעה על הצומת הראשון שמכיל מונח. זה נכון לאתר תוכן,
 * ושגוי לכתבה בעיתון על התעשייה, לעמוד רפואי, או לשיחה שבה מישהו ציטט
 * מילה. התראת שווא אחת בשבוע הראשון והמשתמש מוחק את האפליקציה —
 * ואז הוא בלי הגנה בכלל.
 *
 * שלוש ההחלטות:
 *   1. ניקוד על כל המסך, לא צומת בודד. צריך צפיפות, לא אזכור.
 *   2. יש אפליקציות שלא נסרקות. בנקאות וסיסמאות לעולם.
 *      הודעות — רק בהסכמה מפורשת, כי שם מתנהלות שיחות פרטיות.
 *   3. השהיה וקירור, אחרת זה רץ על כל שינוי פיקסל ושורף סוללה.
 *
 * הניקוד לא נשמר, לא נכתב ללוג ולא יוצא מהמכשיר. מוחזר מספר, לא טקסט.
 */
object ScanPolicy {

    private val NEVER_PREFIX = listOf(
        "com.bank", "com.leumi", "com.poalim", "com.discount", "com.mizrahi",
        "com.isracard", "com.max.", "com.cal", "com.paypal", "com.pepper",
        "com.lastpass", "com.bitwarden", "com.agilebits", "com.dashlane",
        "com.google.android.apps.walletnfcrel", "com.android.keychain",
        "com.google.android.apps.fitness", "com.samsung.android.app.shealth",
        "com.android.vending"
    )

    private val MESSAGING = setOf(
        "com.whatsapp", "org.telegram.messenger", "com.facebook.orca",
        "com.google.android.apps.messaging", "com.discord", "com.snapchat.android"
    )

    /** מונחים שמופיעים גם בהקשר לגיטימי — שווים פחות */
    private val WEAK = setOf("18+", "nudes in bio", "send nudes", "פורנו", "עירום")

    private const val THRESHOLD = 7
    private const val MIN_DISTINCT = 2
    private const val DEBOUNCE_MS = 1_500L
    private const val COOLDOWN_MS = 40_000L

    private var lastScan = 0L
    private var lastHit = 0L
    private var lastPkg = ""

    fun shouldScan(pkg: String, scanMessaging: Boolean): Boolean {
        if (NEVER_PREFIX.any { pkg.startsWith(it) }) return false
        if (pkg in MESSAGING && !scanMessaging) return false
        return true
    }

    /** מחזיר ניקוד אם עבר את הרף. null = לא מתריעים. */
    fun evaluate(root: AccessibilityNodeInfo?, pkg: String, scanMessaging: Boolean): Int? {
        if (root == null) return null
        if (!shouldScan(pkg, scanMessaging)) return null

        val now = SystemClock.elapsedRealtime()
        if (now - lastScan < DEBOUNCE_MS) return null
        lastScan = now
        if (pkg == lastPkg && now - lastHit < COOLDOWN_MS) return null

        val sb = StringBuilder(2048)
        collect(root, sb, 0)
        if (sb.length < 12) return null
        val text = sb.toString().lowercase()

        var score = 0
        var distinct = 0
        for (term in AdultBlockEngine.STRICT_CONTENT_TRIGGERS) {
            var i = text.indexOf(term)
            if (i < 0) continue
            distinct++
            val w = if (term in WEAK) 2 else 4
            var hits = 0
            while (i >= 0 && hits < 4) {   // תקרה למונח, שלא ייווצר ניקוד מנופח
                hits++
                i = text.indexOf(term, i + term.length)
            }
            score += w * hits
        }

        if (score >= THRESHOLD && distinct >= MIN_DISTINCT) {
            lastHit = now
            lastPkg = pkg
            return score
        }
        return null
    }

    /** עומק וגודל מוגבלים — זה רץ הרבה, וסוללה חשובה */
    private fun collect(n: AccessibilityNodeInfo, sb: StringBuilder, depth: Int) {
        if (depth > 12 || sb.length > 6000) return
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, sb, depth + 1) }
    }
}
