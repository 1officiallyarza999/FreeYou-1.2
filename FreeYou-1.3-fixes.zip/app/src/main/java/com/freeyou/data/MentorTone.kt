package com.freeyou.data

/**
 * שלוש רמות אסרטיביות.
 *
 * MentorLines כבר מחזיק את הרמה החמה ("אח גדול") — הקובץ הזה לא מכפיל
 * אותה, הוא מוסיף שתי רמות מעליה ומנתב ביניהן.
 *
 * ===== הקו שלא נחצה בשום רמה =====
 * קשה על התירוץ, לא על האדם. "אתה חלש" מייצר בושה, ובושה היא המנבא
 * החזק ביותר לנפילה הבאה — ההיפך הגמור ממה שהמסך הזה אמור לעשות.
 * לכן גם ברמה הקשוחה הוא מדבר על הדחף בגוף שלישי ועל הגבר בגוף ראשון רבים.
 */
enum class MentorTone(val key: String, val label: String) {
    BROTHER("brother", "אח גדול"),
    COACH("coach", "מאמן"),
    HARD("hard", "קשוח");

    companion object {
        fun from(key: String?): MentorTone =
            values().firstOrNull { it.key == key } ?: COACH
    }
}

private class Bank(
    val open1: List<String>, val open2: List<String>, val night: List<String>,
    val truth: List<String>, val streak: List<String>,
    val act1: List<String>, val act2: List<String>,
)

private val COACH_BANK = Bank(
    open1 = listOf("עצור. תסתכל על מה שאתה עושה עכשיו.", "לא. לא הולכים לשם היום.",
        "תעצור פה. אנחנו לא עושים את זה יותר.", "די. אני נכנס לחדר."),
    open2 = listOf("פעם שנייה היום. אז נעלה הילוך.", "שוב. עכשיו זה כבר לא שיחה."),
    night = listOf("אחרי חצות המוח שלך משקר ומצטדק. אני מזהה את שני הקולות.",
        "השעה הזו לא מקבלת החלטות בשבילנו."),
    truth = listOf("זה לוקח בדיוק את הראש שאתה צריך מחר בבוקר.",
        "עשר דקות של כלום תמורת שבוע של בוץ. המתמטיקה גרועה.",
        "הדחף מבטיח וזורק. הוא עשה את זה כבר מאות פעמים.",
        "בעוד עשרים דקות תהיה אדם אחר. עכשיו נקבע לאיזה כיוון."),
    streak = listOf("{d} ימים. זה לא מספר, זו עבודה. לא זורקים עבודה.",
        "בנינו {d} ימים. אני מגן עליהם עכשיו."),
    act1 = listOf("תכתוב. שתי דקות. זה כל מה שאני מבקש.", "מחברת. עכשיו. ואז נדבר."),
    act2 = listOf("קום. נעליים. דלת. עכשיו.", "תזוז. הגוף פותר את זה, לא הראש."),
)

private val HARD_BANK = Bank(
    open1 = listOf("עצור. עכשיו. אני לא מבקש.", "לא. תוריד את היד.",
        "תעצור. עכשיו נדבר אחרת.", "זה נגמר פה. לא בעוד רגע — פה."),
    open2 = listOf("פעם שנייה. גמרנו לדבר.", "שוב? אז עכשיו הגוף עובד."),
    night = listOf("שלוש לפנות בוקר. השעה הזו לא מנהלת אותנו.",
        "הלילה מציע לך את הדבר הגרוע ביותר. התשובה שלי לא."),
    truth = listOf("זה הקול שמחפש דרך קלה. אני הקול ששורד.",
        "הדחף הזה שיקר לך מאות פעמים. הוא לא הפך אמין בדקה האחרונה.",
        "האיש שאתה רוצה להיות לא נכנס לפה. פשוט לא.",
        "תבחר: עשר דקות של כלום, או האיש שהמשפחה שלך תזכור.",
        "הגל הזה נגמר תוך רבע שעה. לא מוותרים לפני שהוא נגמר."),
    streak = listOf("{d} ימים. אני לא קובר אותם בשלוש דקות. לא קורה.",
        "{d} ימים של עבודה עומדים פה. תעבור עליהם — או תעבור איתם."),
    act1 = listOf("תכתוב. עכשיו. שתי דקות ואני יורד ממך.", "מחברת. עכשיו."),
    act2 = listOf("קום. נעליים. בחוץ. זוז.", "לא מדברים יותר. תזוז."),
)

object MentorToneEngine {

    /** הרמה החמה מנותבת ל-MentorLines הקיים. השתיים האחרות נבנות כאן. */
    fun interceptLine(tone: MentorTone, c: MentorContext, byScan: Boolean = false): String {
        if (tone == MentorTone.BROTHER) return MentorLines.interceptLine(c)

        val b = if (tone == MentorTone.HARD) HARD_BANK else COACH_BANK
        val night = c.hour >= 23 || c.hour < 5
        val second = c.attempt >= 2

        val open = if (second) b.open2.random() else if (night) b.night.random() else b.open1.random()
        val truth = if (c.days >= 3 && Math.random() < 0.5)
            b.streak.random().replace("{d}", c.days.toString()) else b.truth.random()
        val act = if (second) b.act2.random() else b.act1.random()

        // כשהתפיסה הייתה לפי טקסט על המסך ולא לפי כתובת, הוא אומר את זה
        val lead = if (byScan) "ראיתי מה על המסך. " else ""
        return lead + listOf(open, truth, act).joinToString(" ")
    }

    /** כל המשפטים ברמה — לחימום הקאש הקולי */
    fun allLines(tone: MentorTone): List<String> {
        if (tone == MentorTone.BROTHER) return emptyList()
        val b = if (tone == MentorTone.HARD) HARD_BANK else COACH_BANK
        return b.open1 + b.open2 + b.night + b.truth +
            b.streak.map { it.replace("{d}", "30") } + b.act1 + b.act2
    }
}
