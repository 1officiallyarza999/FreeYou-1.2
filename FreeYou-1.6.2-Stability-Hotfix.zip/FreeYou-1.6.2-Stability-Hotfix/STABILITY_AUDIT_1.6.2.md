# 1.6.2 stability audit

Root causes confirmed in 1.6.1:
1. MentorOverlay's return callback invoked `goHome()`, which explicitly opened Android HOME.
2. BlockInterventionCoordinator showed the overlay and then also force-launched MainActivity.
3. VPN background DNS requests could trigger a second intervention after the 12-second cooldown even if the original browser tab was only sitting in the background.
4. SystemUI was not excluded early enough from Accessibility handling.
5. BlockRepo.init() and AdultShieldUpdater.maybeRefresh() ran on every Accessibility event, increasing unnecessary work.
6. Deep tree/content scans ran on frequent content-changed and scroll events without throttling.
7. Every allowed DNS query could spawn another forwarding coroutine/socket without a concurrency bound.

1.6.2 separates network blocking from mentor UI and makes interventions navigation-scoped rather than packet-scoped.
