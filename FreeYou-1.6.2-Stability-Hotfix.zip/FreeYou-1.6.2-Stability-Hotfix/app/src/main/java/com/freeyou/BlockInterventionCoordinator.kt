package com.freeyou

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import com.freeyou.data.BlockRepo

/**
 * Central intervention coordinator.
 *
 * Important rule: blocking and coaching are separate concerns. DNS can keep blocking every
 * request, but the UI/mentor must only appear once for a real navigation attempt.
 */
object BlockInterventionCoordinator {
    private const val TAG = "FreeYouIntervention"
    private const val GLOBAL_UI_COOLDOWN_MS = 10_000L
    private const val VPN_UI_QUIET_WINDOW_MS = 60_000L
    private const val AFTER_RETURN_QUIET_WINDOW_MS = 45_000L
    private const val SAFE_PAGE_URL = "https://www.google.com/"

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile private var lastUiTriggerAt = 0L
    @Volatile private var vpnQuietUntil = 0L
    @Volatile private var userQuietUntil = 0L
    @Volatile private var lastKnownBrowserPackage: String? = null

    fun noteBrowserPackage(packageName: String) {
        if (packageName.isNotBlank()) lastKnownBrowserPackage = packageName
    }

    @Synchronized
    fun trigger(
        context: Context,
        target: String,
        source: String = "unknown",
        browserPackage: String? = null,
        pageAlreadyExited: Boolean = false
    ) {
        val now = System.currentTimeMillis()
        val isVpnSource = source.startsWith("vpn")

        browserPackage?.takeIf { it.isNotBlank() }?.let { lastKnownBrowserPackage = it }

        // The network block remains active even when the mentor UI is suppressed.
        if (MentorOverlay.isShowing()) return
        if (now < userQuietUntil && isVpnSource) return
        if (isVpnSource && now < vpnQuietUntil) return
        if (now - lastUiTriggerAt < GLOBAL_UI_COOLDOWN_MS) return

        lastUiTriggerAt = now
        if (isVpnSource) vpnQuietUntil = now + VPN_UI_QUIET_WINDOW_MS

        val appContext = context.applicationContext
        val normalizedTarget = target.trim().ifEmpty { "18+ content" }
        val resolvedBrowser = browserPackage ?: lastKnownBrowserPackage

        mainHandler.post {
            performIntervention(
                context = appContext,
                target = normalizedTarget,
                source = source,
                browserPackage = resolvedBrowser,
                pageAlreadyExited = pageAlreadyExited
            )
        }
    }

    private fun performIntervention(
        context: Context,
        target: String,
        source: String,
        browserPackage: String?,
        pageAlreadyExited: Boolean
    ) {
        BlockRepo.init(context)
        val count = BlockRepo.bumpAttempt()
        val nextRoute = if (count <= 1) "journal" else "mission"
        BlockRepo.setPendingRoute(nextRoute, target, count)

        Log.w(TAG, "Blocked target=$target source=$source attempt=$count")

        val canOverlay = Settings.canDrawOverlays(context)
        if (canOverlay && !MentorOverlay.isShowing()) {
            MentorOverlay.show(
                context,
                count,
                onContinue = {
                    BlockRepo.clearPendingRoute()
                    launchApp(context, nextRoute, target, count)
                },
                onBack = {
                    // "I'm going back" must never throw the user to the launcher.
                    // Accessibility already pressed BACK before the overlay appeared, so in that
                    // path simply dismissing the overlay leaves the browser on its previous page.
                    BlockRepo.clearPendingRoute()
                    userQuietUntil = System.currentTimeMillis() + AFTER_RETURN_QUIET_WINDOW_MS
                    vpnQuietUntil = maxOf(vpnQuietUntil, userQuietUntil)

                    // VPN-only interception has no Accessibility BACK action. In that rare case,
                    // navigate to a safe page using the same browser when possible.
                    if (!pageAlreadyExited) {
                        openSafePage(context, browserPackage)
                    }
                }
            )
            // Do NOT force-launch FreeYou here. The overlay is the intervention. Launching the
            // activity as well was causing app switching, duplicate navigation and a "phone going
            // crazy" feeling.
            return
        }

        // Fallback for devices where overlay permission is missing/disabled.
        launchApp(context, "intercept", target, count)
    }

    private fun openSafePage(context: Context, browserPackage: String?) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(SAFE_PAGE_URL)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                browserPackage?.let { setPackage(it) }
            }

            // If a remembered browser is no longer installed, retry with the default browser.
            try {
                context.startActivity(intent)
            } catch (_: Throwable) {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(SAFE_PAGE_URL)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                )
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Could not open safe browser page: ${t.message}")
        }
    }

    private fun launchApp(context: Context, route: String, target: String, count: Int) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra("freeyou_route", route)
                putExtra("freeyou_target", target)
                putExtra("freeyou_count", count)
            }
            context.startActivity(intent)
        } catch (t: Throwable) {
            Log.w(TAG, "Could not launch intercept activity: ${t.message}")
        }
    }
}
