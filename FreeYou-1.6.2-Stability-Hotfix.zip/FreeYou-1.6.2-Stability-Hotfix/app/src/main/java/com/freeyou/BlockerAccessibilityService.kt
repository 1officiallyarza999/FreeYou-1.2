package com.freeyou

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.freeyou.data.AdultBlockEngine
import com.freeyou.data.BlockRepo

class BlockerAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "FreeYouBlocker"
        private const val MAX_TREE_DEPTH = 12
        private const val MAX_SCREEN_TEXT_CHARS = 12_000
        private const val CONTENT_SCAN_THROTTLE_MS = 300L

        private val BROWSER_URL_IDS = listOf(
            "com.android.chrome:id/url_bar",
            "com.android.chrome:id/search_box_text",
            "org.mozilla.firefox:id/url_bar_title",
            "org.mozilla.firefox:id/mozac_browser_toolbar_url_view",
            "org.mozilla.firefox:id/url_bar",
            "com.brave.browser:id/url_bar",
            "com.brave.browser:id/search_box_text",
            "com.opera.browser:id/url_field",
            "com.opera.mini.native:id/url_field",
            "com.opera.gx:id/url_field",
            "com.sec.android.app.sbrowser:id/location_bar_edit_text",
            "com.sec.android.app.sbrowser:id/url_bar",
            "com.microsoft.emmx:id/url_bar",
            "com.microsoft.emmx:id/search_box",
            "com.duckduckgo.mobile.android:id/omnibarTextInput",
            "com.kiwibrowser.browser:id/url_bar",
            "com.vivaldi.browser:id/url_bar"
        )

        private val BROWSER_PACKAGES = setOf(
            "com.android.chrome",
            "org.mozilla.firefox",
            "com.brave.browser",
            "com.opera.browser",
            "com.opera.mini.native",
            "com.opera.gx",
            "com.sec.android.app.sbrowser",
            "com.microsoft.emmx",
            "com.duckduckgo.mobile.android",
            "com.kiwibrowser.browser",
            "com.vivaldi.browser"
        )

        private val SOCIAL_PACKAGES = setOf(
            "com.twitter.android",
            "com.x.android",
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.instagram.android",
            "com.reddit.frontpage",
            "org.telegram.messenger",
            "org.telegram.plus"
        )

        // Never inspect transient system surfaces. This fixes re-triggering when the user opens
        // the notification/quick-settings shade, keyboard, launcher, permission UI, etc.
        private val IGNORED_PACKAGES = setOf(
            "com.android.systemui",
            "com.android.launcher",
            "com.android.launcher3",
            "com.sec.android.app.launcher",
            "com.google.android.apps.nexuslauncher",
            "com.google.android.inputmethod.latin",
            "com.samsung.android.honeyboard",
            "com.android.permissioncontroller",
            "com.google.android.permissioncontroller",
            "com.samsung.android.app.aodservice"
        )
    }

    private var lastContentScanAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "FreeYou Accessibility Blocker connected.")
        BlockRepo.init(this)
        MentorOverlay.init(this)
        AdultShieldUpdater.maybeRefresh(this)
    }

    override fun onAccessibilityEvent(ev: AccessibilityEvent?) {
        if (ev == null) return

        val pkg = ev.packageName?.toString() ?: return

        // Hard self-protection and system-surface protection happen before ANY repository or tree
        // work. FreeYou and Android System UI can never become adult-content triggers.
        if (isOwnPackage(pkg) || pkg in IGNORED_PACKAGES) return

        if (pkg in BROWSER_PACKAGES) {
            BlockInterventionCoordinator.noteBrowserPackage(pkg)
        }

        val appBlock = BlockRepo.isAppBlocked(pkg, ev.className?.toString())
        if (appBlock != null) {
            trigger(appBlock, pkg)
            return
        }

        // Accessibility can emit a huge burst of window-content and scroll events. Throttle only
        // those noisy event types; text edits/window changes still pass immediately.
        val now = System.currentTimeMillis()
        val noisyEvent = ev.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            ev.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED
        if (noisyEvent && now - lastContentScanAt < CONTENT_SCAN_THROTTLE_MS) return
        if (noisyEvent) lastContentScanAt = now

        val root = rootInActiveWindow ?: return
        val rootPkg = root.packageName?.toString()

        if (isOwnPackage(rootPkg) || rootPkg in IGNORED_PACKAGES) {
            @Suppress("DEPRECATION")
            root.recycle()
            return
        }

        try {
            if (pkg == "com.android.settings" && BlockRepo.state.value.strict) {
                if (checkSettingsAntiBypass(root)) {
                    trigger("הגדרות נגישות (מצב קשוח פעיל)", pkg)
                    return
                }
                // Settings is only inspected for anti-bypass. Never sexual-content scan Settings.
                return
            }

            val isKnownBrowser = pkg in BROWSER_PACKAGES
            val isKnownSocial = pkg in SOCIAL_PACKAGES
            val unknownBrowserWithUrlBar = !isKnownBrowser && !isKnownSocial && hasUrlLikeNode(root, 0)
            val deepScan = isKnownBrowser || isKnownSocial || unknownBrowserWithUrlBar

            if (!deepScan) return

            // First inspect URL/domain nodes. This is cheap and is the strongest signal.
            val detectedBlock = inspectNodeHierarchy(root, 0, scanContent = false)
            if (detectedBlock != null) {
                trigger(detectedBlock, pkg)
                return
            }

            // Then perform one aggregate content check for genuinely browser/social surfaces.
            val screenText = StringBuilder()
            collectVisibleText(root, 0, screenText)
            val screenHit = AdultBlockEngine.checkScreenText(screenText)
            if (screenHit != null) {
                trigger(screenHit, pkg)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Error inspecting accessibility window: ${t.message}", t)
        } finally {
            @Suppress("DEPRECATION")
            root.recycle()
        }
    }

    private fun isOwnPackage(pkg: String?): Boolean {
        return !pkg.isNullOrBlank() && pkg == applicationContext.packageName
    }

    private fun hasUrlLikeNode(node: AccessibilityNodeInfo, depth: Int): Boolean {
        if (depth > 7) return false
        val viewId = node.viewIdResourceName?.lowercase().orEmpty()
        if (isUrlViewId(viewId)) return true

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (hasUrlLikeNode(child, depth + 1)) return true
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }
        return false
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo, depth: Int, out: StringBuilder) {
        if (depth > MAX_TREE_DEPTH || out.length >= MAX_SCREEN_TEXT_CHARS) return

        node.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let {
            out.append(' ').append(it.take(600))
        }
        node.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let {
            out.append(' ').append(it.take(600))
        }

        for (i in 0 until node.childCount) {
            if (out.length >= MAX_SCREEN_TEXT_CHARS) break
            val child = node.getChild(i) ?: continue
            try {
                collectVisibleText(child, depth + 1, out)
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }
    }

    private fun inspectNodeHierarchy(
        node: AccessibilityNodeInfo,
        depth: Int,
        scanContent: Boolean
    ): String? {
        if (depth > MAX_TREE_DEPTH) return null
        if (isOwnPackage(node.packageName?.toString())) return null

        val viewId = node.viewIdResourceName?.lowercase().orEmpty()
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()

        if (isUrlViewId(viewId) && !text.isNullOrBlank()) {
            BlockRepo.isUrlBlocked(text)?.let { return it }
            if (scanContent) BlockRepo.checkContentTrigger(text)?.let { return it }
        }

        if (!text.isNullOrBlank() && looksUrlLike(text)) {
            BlockRepo.isUrlBlocked(text)?.let { return it }
        }

        if (!desc.isNullOrBlank() && looksUrlLike(desc)) {
            BlockRepo.isUrlBlocked(desc)?.let { return it }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                val result = inspectNodeHierarchy(child, depth + 1, scanContent)
                if (result != null) return result
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }

        return null
    }

    private fun isUrlViewId(viewId: String): Boolean {
        if (viewId.isBlank()) return false
        return BROWSER_URL_IDS.any { viewId == it || viewId.contains(it) } ||
            viewId.contains("url_bar") ||
            viewId.contains("omnibox") ||
            viewId.contains("location_bar") ||
            viewId.contains("address_bar")
    }

    private fun looksUrlLike(value: String): Boolean {
        val v = value.trim().lowercase()
        return v.startsWith("http://") || v.startsWith("https://") ||
            (v.length in 4..300 && !v.contains(' ') && v.contains('.'))
    }

    private fun checkSettingsAntiBypass(node: AccessibilityNodeInfo): Boolean {
        val text = node.text?.toString()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase().orEmpty()
        if (text.contains("freeyou") || desc.contains("freeyou")) return true

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (checkSettingsAntiBypass(child)) return true
            } finally {
                @Suppress("DEPRECATION")
                child.recycle()
            }
        }
        return false
    }

    private fun trigger(target: String, browserPackage: String?) {
        Log.w(TAG, "INTERCEPT TRIGGERED: $target")

        // Exit the blocked page once, before showing the mentor overlay. The user's "I'm going
        // back" button can now simply dismiss the overlay and leave them in the same browser.
        val backedOut = performGlobalAction(GLOBAL_ACTION_BACK)
        BlockInterventionCoordinator.trigger(
            context = this,
            target = target,
            source = "accessibility",
            browserPackage = browserPackage?.takeIf { it in BROWSER_PACKAGES },
            pageAlreadyExited = backedOut
        )
    }

    override fun onInterrupt() {
        Log.i(TAG, "FreeYou Accessibility Blocker interrupted.")
    }
}
