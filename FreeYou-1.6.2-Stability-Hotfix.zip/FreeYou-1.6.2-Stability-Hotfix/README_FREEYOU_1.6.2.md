# FreeYou 1.6.2 Stability Hotfix

This hotfix targets the instability seen after a blocked-page intervention.

## Fixed
- The "I'm going back" action no longer sends the user to the Android launcher.
- FreeYou no longer force-opens its own Activity while the mentor overlay is already visible.
- Notification shade / System UI / launcher / keyboard surfaces are ignored before any content scan.
- The Accessibility service no longer reparses preferences and runs updater checks on every UI event.
- Noisy Accessibility content/scroll events are throttled to reduce CPU churn.
- VPN DNS blocking stays active, while repeated background DNS requests cannot repeatedly summon the mentor UI.
- A 45-second post-return UI quiet window prevents stale page subresources from re-triggering the mentor.
- When interception came only from VPN, returning opens a safe page in the remembered browser when possible.
- Pending intervention routes are cleared when the user chooses to return, preventing a surprise journal screen later.
- Upstream DNS queries are concurrency-limited to avoid unbounded coroutine/socket bursts.

## Version
- versionName: 1.6.2
- versionCode: 18
